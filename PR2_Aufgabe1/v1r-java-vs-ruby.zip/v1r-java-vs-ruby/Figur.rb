require "Object"
module Figur
  def in(p)
    abstract
  end
end